#coding:utf-8
'''显然，如果n=m+1，那么由于一次最多只能取m个，所以，无论先取者拿走多少个，后取者都能够一次
拿走剩余的物品，后者取胜。因此我们发现了如何取胜的法则：如果n=（m+1）r+s，（r为任意自然数，s
≤m),那么先取者要拿走s个物品，如果后取者拿走k（≤m)个，那么先取者再拿走m+1-k个，结果剩下
（m+1）（r-1）个，以后保持这样的取法，那么先取者肯定获胜。总之，要保持给对手留下（m+1）的倍
数，就能最后获胜。'''


import socket
import time
import re

# 1 Socket Init
# 1.1 Set Host and Port
HOST, PORT = "10.105.42.5",int(43333)

# 1.2 Connect to Server
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect((HOST, PORT))

n=0
# 2 Receive the Message from Server
# [sleep() before recv() is necessary]
while True:
    time.sleep(0.01)
    response = sock.recv(1024)
    print response

    p = re.findall(r'\d+',response)
    if re.findall('-',response):
        a = int(p[1])
        n = int(p[2])
    else:
        a = int(p[0])

    y = a%(n+1)
    sendBuf = str(y)+'\n'
    sock.send(sendBuf)
    #print sendBuf


sock.close()


#time.sleep(10)
