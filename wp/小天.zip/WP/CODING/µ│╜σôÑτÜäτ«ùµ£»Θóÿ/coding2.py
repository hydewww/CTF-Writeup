# "exampleClient.py" is a simple client programed by Python.
# It can connect to the server, solve the question, and finally capture the flag.
# It's only a example. In the real test, you have to program it by yourself.

import socket
import time
import re

def pow(a, n, b=10000):
    result =1
    while n > 0 :
        if n%2 == 1 :
            result = result*a%b
        n = n/2
        a= a*a%b

    return result


# 1 Socket Init
# 1.1 Set Host and Port
HOST, PORT = "10.105.42.5", int(42222)

# 1.2 Connect to Server
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect((HOST, PORT))

allr=''
while True:
# 2 Receive the Message from Server
# [sleep() before recv() is necessary]
    time.sleep(0.1)
    response = sock.recv(1024)
    print response
    p = re.findall(r'\d+',response)
    a = int(p[1])
    n = int(p[2])

    ret = pow(a,n)

# 3 Send the Answer to Server
    sendBuf = str(ret)+'\n'
    sock.send(sendBuf)
    print sendBuf

# 5 Close the Socket
sock.close()


time.sleep(10)
