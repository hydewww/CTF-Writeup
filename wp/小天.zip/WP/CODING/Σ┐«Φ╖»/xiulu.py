#!/bin/python
#coding:utf-8

import networkx as nx
import re
import time
import socket


G = nx.Graph()
for i in range(1,1001) :
	G.add_node(i)

HOST, PORT = "10.105.42.5", int(44444)

# 1.2 Connect to Server
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect((HOST, PORT))

time.sleep(0.05)
response = sock.recv(1024)
print response
sock.send("\n")

time.sleep(0.05)
response = sock.recv(1024*10)
print response

roads = response
p = re.findall(r"\d+ \d+", roads)
#print len(p)
road_num = len(p)
i = 1
while i <= road_num-1 :
	rds = p[i-1].split()
	G.add_edge(rds[0],rds[1])
	i = i + 1

#print "number of edges-->"+str(G.number_of_edges())
path = nx.all_pairs_shortest_path(G)

def getrd( nodes):
	nd1 = nodes.split()[0]
	nd2 = nodes.split()[1]
	try :
		tmp = path[nd1][nd2]
		return 'yes'
	except :
		return 'no'
	
	return 'yes'

isok = getrd(p[-1])
sock.send(isok+"\n")

while True :
	time.sleep(0.05)
	response = sock.recv(80)
	print response
	nodes = re.findall(r"\d+ \d+", response)

	isok = getrd(nodes[0])
	sock.send(isok+"\n")

sock.close()
print "the end!"

