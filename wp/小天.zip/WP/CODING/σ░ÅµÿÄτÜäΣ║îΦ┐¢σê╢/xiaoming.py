#!/bin/python
#coding:utf-8

import socket
import re
import time

def getcnt(num) :
    if num == 0 :
        return 0
    num_str = str(num)
    cnt = 1
    num_len = len(num_str)
    tmp_xm = ''
    for i in range(num_len):
        if num_str[i:i+1] > '0' :
            tmp_xm = tmp_xm + '1'
        else:
            tmp_xm = tmp_xm + '0'

    num_less = num - int(tmp_xm)
    cnt = cnt + getcnt(num_less)

    return cnt

# 1 Socket Init
# 1.1 Set Host and Port
# HOST, PORT = "127.0.0.1", int(42222)
HOST, PORT = "10.105.42.5", int(41111)

# 1.2 Connect to Server
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect((HOST, PORT))

for i in range(51):
    # 2 Receive the Message from Server
    # [sleep() before recv() is necessary]
    time.sleep(0.2)
    response = sock.recv(1024)
    print response

    p = re.findall(r'\d+', response)
    if len(p) == 0 :
        print "!!!!!can not get the num !!!"
        exit()
    num = p[len(p)-1]
    cnt = getcnt(int(num))
    # 3 Send the Answer to Server

    sendBuf = str(cnt) + "\n"
    print  sendBuf
    sock.send(sendBuf)
    # print sendBuf

sock.close()
print "sock close!!!"