import itertools
import md5
words = 'ahkqy$%'
for i in (1,2,3,4,5,6,7):
    r = itertools.product(words,repeat=i)
    for j in r:
        m1 = md5.new()
        m1.update("".join(j))
        if(m1.hexdigest() == '24885fdab795c41166d6f0067782dc9f'):
            print "".join(j)
print "stop"