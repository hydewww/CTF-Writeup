#include <stdlib.h>
#include <stdio.h>
#include <time.h>

int main(int argc, char ** argv)
{

	srand(time(0));
	
	printf("%d\n", rand()%1000);
	return 0;
}
