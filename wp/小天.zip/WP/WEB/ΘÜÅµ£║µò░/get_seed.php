<?php
function get_user_Key()
{
    mt_srand();
    $_SESSION['user_key'] = md5(mt_rand());
	print $_SESSION['user_key']."\n";
    $_SESSION['id'] = md5(mt_rand());
	print $_SESSION['id']."\n";
    return "your id is {$_SESSION['id']}!";
}

#get_user_key();
$tgt = 47265856; 
print $tgt."\n";

$seed = 1;
while ($seed <= 4294967295){
	mt_srand($seed);
	$rd1 = mt_rand();
	$rd2 = mt_rand();
	if($rd2 == $tgt ){
	    print "seed is -->".$seed."\n";
	}	
	
	$seed = $seed + 1;
}	

?>
