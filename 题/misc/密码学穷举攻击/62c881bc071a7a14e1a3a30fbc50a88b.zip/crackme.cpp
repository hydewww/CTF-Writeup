// crackme.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <math.h>
#include <Windows.h>

unsigned long pow_mod(unsigned long vsn, unsigned int e)
{
	unsigned __int64 v4; // [sp+4Ch] [bp-Ch]@1
	unsigned int i; // [sp+54h] [bp-4h]@1

	i = 0;
	v4 = 1i64;
	if (e && vsn)
	{
		for (i = 0; i < e; ++i)
			v4 = v4 * (unsigned __int64)vsn % 0xFFFFFFFF;
	}
	else
	{
		v4 = vsn != 0;
	}
	return (unsigned long)v4;
}

unsigned long get_ulong(char *str, int radix)
{
	char temp[9] = { 0 };
	memcpy(temp, str, 8);
	return strtoul(temp, 0, radix);
}

int _tmain(int argc, _TCHAR* argv[])
{
	char sn[32] = { 0 };
	printf("��˼���� CTF 2017 CrackMe\n");

	printf("Please input serial:");
	scanf("%s", sn);

	unsigned long m1 = get_ulong(&sn[0], 16);
	unsigned long m2 = get_ulong(&sn[8], 16);

	unsigned long e = (m2 ^ m1) % 0x1000000;
	if (e > 2 && m1 && m2)
	{
		unsigned long c1 = pow_mod(m1, e);
		unsigned long c2 = pow_mod(m2, e);

		if ((c1 + c2) == 0x85ba527a && (c1 - c2) == 0x8393f16e)
		{
			printf("Congratulations, registration successful!\n\n");
			return 0;
		}
	}

	printf("Registration failed, try again!\n\n");
	return -1;
}

